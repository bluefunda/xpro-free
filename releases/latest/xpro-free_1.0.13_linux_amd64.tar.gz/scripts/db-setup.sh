#!/bin/bash
# XPro Database Setup Script
# Creates the xpro schema and required tables in PostgreSQL
#
# Required environment variables:
#   POSTGRES_HOST - Database host
#   POSTGRES_PORT - Database port
#   POSTGRES_SECRET_KEY - Database password
#   POSTGRES_USER - Database user (default: postgres)
#   POSTGRES_DB - Database name (default: postgres)
#
# Usage: ./db-setup.sh [--schema SCHEMA_NAME]

set -e

# Default values
SCHEMA_NAME="${XPRO_SCHEMA:-xpro}"
POSTGRES_USER="${POSTGRES_USER:-postgres}"
POSTGRES_DB="${POSTGRES_DB:-postgres}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --schema)
            SCHEMA_NAME="$2"
            shift 2
            ;;
        --help)
            echo "Usage: $0 [--schema SCHEMA_NAME]"
            echo ""
            echo "Required environment variables:"
            echo "  POSTGRES_HOST       - Database host"
            echo "  POSTGRES_PORT       - Database port"
            echo "  POSTGRES_SECRET_KEY - Database password"
            echo ""
            echo "Optional environment variables:"
            echo "  POSTGRES_USER       - Database user (default: postgres)"
            echo "  POSTGRES_DB         - Database name (default: postgres)"
            echo "  XPRO_SCHEMA         - Schema name (default: xpro)"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Validate required environment variables
if [[ -z "$POSTGRES_HOST" ]]; then
    log_error "POSTGRES_HOST environment variable is not set"
    exit 1
fi

if [[ -z "$POSTGRES_PORT" ]]; then
    log_error "POSTGRES_PORT environment variable is not set"
    exit 1
fi

if [[ -z "$POSTGRES_SECRET_KEY" ]]; then
    log_error "POSTGRES_SECRET_KEY environment variable is not set"
    exit 1
fi

# Check if psql is available
if ! command -v psql &> /dev/null; then
    log_error "psql command not found. Please install postgresql-client."
    exit 1
fi

log_info "Connecting to PostgreSQL at $POSTGRES_HOST:$POSTGRES_PORT..."

# Test connection
export PGPASSWORD="$POSTGRES_SECRET_KEY"
if ! psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "SELECT 1" > /dev/null 2>&1; then
    log_error "Failed to connect to PostgreSQL"
    exit 1
fi

log_info "Connection successful. Creating schema and tables..."

# SQL to create schema and tables
SQL=$(cat <<'EOSQL'
-- Create schema if not exists
CREATE SCHEMA IF NOT EXISTS ${SCHEMA};

-- Set search path
SET search_path TO ${SCHEMA};

-- ============================================================================
-- BILL_DATA table (for xml-billdata processing mode)
-- ============================================================================
CREATE TABLE IF NOT EXISTS ${SCHEMA}.bill_data (
    id BIGSERIAL PRIMARY KEY,
    company_code VARCHAR(8),
    line_of_business VARCHAR(8),
    xml XML,
    job_type VARCHAR(2),
    letter_code VARCHAR(5),
    status VARCHAR(25),
    master_acc_number VARCHAR(20),
    account_number VARCHAR(20),
    customer_number VARCHAR(20),
    premise_number VARCHAR(20),
    bill_date TIMESTAMP WITH TIME ZONE,
    print_date TIMESTAMP WITH TIME ZONE,
    version INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(20),
    updated_by VARCHAR(20),
    error_code VARCHAR(20),
    error_message VARCHAR(150),
    retry_count INTEGER DEFAULT 0,
    reference_id VARCHAR(40),
    load_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    cycle_date TIMESTAMP WITH TIME ZONE,
    xml_clob TEXT,
    source_system VARCHAR(20)
);

-- Indexes for bill_data
CREATE INDEX IF NOT EXISTS idx_bill_data_status ON ${SCHEMA}.bill_data(status);
CREATE INDEX IF NOT EXISTS idx_bill_data_account ON ${SCHEMA}.bill_data(account_number);
CREATE INDEX IF NOT EXISTS idx_bill_data_bill_date ON ${SCHEMA}.bill_data(bill_date);
CREATE INDEX IF NOT EXISTS idx_bill_data_created_at ON ${SCHEMA}.bill_data(created_at);

-- ============================================================================
-- FILE_STATE table (for DLQ pattern and fault tolerance)
-- ============================================================================
CREATE TABLE IF NOT EXISTS ${SCHEMA}.file_state (
    file_path VARCHAR(500) PRIMARY KEY,
    batch_id VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    retry_count INT NOT NULL DEFAULT 0,
    error_message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMP,
    CONSTRAINT chk_file_state_status CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'retrying'))
);

-- Indexes for file_state
CREATE INDEX IF NOT EXISTS idx_file_state_status_retry ON ${SCHEMA}.file_state(status, retry_count)
    WHERE status IN ('failed', 'retrying');
CREATE INDEX IF NOT EXISTS idx_file_state_batch_id ON ${SCHEMA}.file_state(batch_id);
CREATE INDEX IF NOT EXISTS idx_file_state_created_at ON ${SCHEMA}.file_state(created_at);

-- Trigger for auto-updating updated_at
CREATE OR REPLACE FUNCTION ${SCHEMA}.update_file_state_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_file_state_updated_at ON ${SCHEMA}.file_state;
CREATE TRIGGER trg_file_state_updated_at
    BEFORE UPDATE ON ${SCHEMA}.file_state
    FOR EACH ROW
    EXECUTE FUNCTION ${SCHEMA}.update_file_state_timestamp();

-- ============================================================================
-- ANALYSIS_RUNS table (for json-analysis processing mode)
-- ============================================================================
CREATE TABLE IF NOT EXISTS ${SCHEMA}.analysis_runs (
    id SERIAL PRIMARY KEY,
    run_id VARCHAR(255) UNIQUE NOT NULL,
    timestamp_utc TIMESTAMP NOT NULL,
    system_id VARCHAR(255),
    system_release VARCHAR(255),
    client VARCHAR(255),
    analyst VARCHAR(255),
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_file VARCHAR(500)
);

-- ============================================================================
-- ANALYSIS_ARTIFACTS table
-- ============================================================================
CREATE TABLE IF NOT EXISTS ${SCHEMA}.analysis_artifacts (
    id SERIAL PRIMARY KEY,
    run_id VARCHAR(255) REFERENCES ${SCHEMA}.analysis_runs(run_id) ON DELETE CASCADE,
    artifact_name VARCHAR(255),
    artifact_type VARCHAR(255),
    package VARCHAR(255),
    transport_request VARCHAR(255)
);

-- ============================================================================
-- ANALYSIS_ISSUES table
-- ============================================================================
CREATE TABLE IF NOT EXISTS ${SCHEMA}.analysis_issues (
    id SERIAL PRIMARY KEY,
    run_id VARCHAR(255) REFERENCES ${SCHEMA}.analysis_runs(run_id) ON DELETE CASCADE,
    pattern_id VARCHAR(255),
    pattern_title VARCHAR(255),
    symptom_detected TEXT,
    severity VARCHAR(50),
    before_code TEXT,
    after_code TEXT,
    fix_description TEXT
);

-- Indexes for analysis tables
CREATE INDEX IF NOT EXISTS idx_analysis_runs_run_id ON ${SCHEMA}.analysis_runs(run_id);
CREATE INDEX IF NOT EXISTS idx_analysis_runs_timestamp ON ${SCHEMA}.analysis_runs(timestamp_utc);
CREATE INDEX IF NOT EXISTS idx_analysis_artifacts_run_id ON ${SCHEMA}.analysis_artifacts(run_id);
CREATE INDEX IF NOT EXISTS idx_analysis_issues_run_id ON ${SCHEMA}.analysis_issues(run_id);
CREATE INDEX IF NOT EXISTS idx_analysis_issues_severity ON ${SCHEMA}.analysis_issues(severity);

-- ============================================================================
-- Comments for documentation
-- ============================================================================
COMMENT ON SCHEMA ${SCHEMA} IS 'XPro data processing schema';
COMMENT ON TABLE ${SCHEMA}.bill_data IS 'Stores billing data from XML files';
COMMENT ON TABLE ${SCHEMA}.file_state IS 'Tracks file processing state for DLQ pattern';
COMMENT ON TABLE ${SCHEMA}.analysis_runs IS 'Stores metadata for each analysis run';
COMMENT ON TABLE ${SCHEMA}.analysis_artifacts IS 'Stores artifact information for each analysis run';
COMMENT ON TABLE ${SCHEMA}.analysis_issues IS 'Stores detected issues and patterns for each analysis run';

EOSQL
)

# Replace ${SCHEMA} placeholder with actual schema name
SQL="${SQL//\$\{SCHEMA\}/$SCHEMA_NAME}"

# Execute SQL
echo "$SQL" | psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1

if [[ $? -eq 0 ]]; then
    log_info "Database setup completed successfully!"
    log_info "Schema: $SCHEMA_NAME"
    log_info "Tables created: bill_data, file_state, analysis_runs, analysis_artifacts, analysis_issues"
else
    log_error "Database setup failed!"
    exit 1
fi

# Verify tables
log_info "Verifying tables..."
TABLE_COUNT=$(psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '$SCHEMA_NAME'")

log_info "Found $TABLE_COUNT tables in schema '$SCHEMA_NAME'"

unset PGPASSWORD
